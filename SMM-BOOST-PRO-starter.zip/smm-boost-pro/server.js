require("dotenv").config();
const express = require("express");
const path = require("path");

const app = express();
app.use(express.json());
app.use(express.static(path.join(__dirname, "public")));

const PORT = process.env.PORT || 3000;
const API_URL = process.env.SMM_API_URL || "https://smm-cambodia.com/api/v2";
const API_KEY = process.env.SMM_API_KEY;

async function smmRequest(params) {
  if (!API_KEY) throw new Error("សូមកំណត់ SMM_API_KEY ក្នុងឯកសារ .env ជាមុន");
  const body = new URLSearchParams({ key: API_KEY, ...params });
  const response = await fetch(API_URL, {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body
  });
  if (!response.ok) throw new Error(`Provider API error: ${response.status}`);
  const data = await response.json();
  if (data && data.error) throw new Error(data.error);
  return data;
}

app.get("/api/health", (_req, res) => res.json({ ok: true, providerConfigured: Boolean(API_KEY) }));

app.get("/api/services", async (_req, res) => {
  try {
    const data = await smmRequest({ action: "services" });
    res.json(data);
  } catch (err) {
    res.status(502).json({ error: err.message });
  }
});

app.get("/api/balance", async (_req, res) => {
  try {
    const data = await smmRequest({ action: "balance" });
    res.json(data);
  } catch (err) {
    res.status(502).json({ error: err.message });
  }
});

app.post("/api/order", async (req, res) => {
  const { service, link, quantity } = req.body || {};
  const qty = Number(quantity);
  if (!service || !link || !Number.isInteger(qty) || qty < 1) {
    return res.status(400).json({ error: "សូមបំពេញសេវាកម្ម Link និងចំនួនឱ្យបានត្រឹមត្រូវ" });
  }
  try {
    const data = await smmRequest({
      action: "add",
      service: String(service),
      link: String(link),
      quantity: String(qty)
    });
    res.json(data);
  } catch (err) {
    res.status(502).json({ error: err.message });
  }
});

app.get("/api/order/:id", async (req, res) => {
  try {
    const data = await smmRequest({ action: "status", order: req.params.id });
    res.json(data);
  } catch (err) {
    res.status(502).json({ error: err.message });
  }
});

app.get("*", (_req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));
app.listen(PORT, () => console.log(`SMM BOOST PRO running at http://localhost:${PORT}`));
