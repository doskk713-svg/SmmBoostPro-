# SMM BOOST PRO

## Requirements
- Node.js 18 or newer
- SMM Cambodia API key

## Run locally
1. Extract this ZIP.
2. Open a terminal in this folder.
3. Run `npm install`.
4. Copy `.env.example` to `.env`.
5. Put your real API key in `.env` as `SMM_API_KEY=...`.
6. Run `npm start`.
7. Open http://localhost:3000

## Important
- Never put the provider API key in `public/index.html` or share it publicly.
- This is a starter template. It sends orders to the provider, but it does not yet include customer login, wallet/deposit, payment gateway, admin authentication, markup pricing, or Telegram bot integration.
- Check the provider's current API documentation and confirm supported actions/parameters before going live.
- Do not expose `/api/balance` publicly in a production deployment; protect admin routes with authentication first.
